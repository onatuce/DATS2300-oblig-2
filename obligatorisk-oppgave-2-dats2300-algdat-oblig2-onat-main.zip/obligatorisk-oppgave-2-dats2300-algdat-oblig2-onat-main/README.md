[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/FVZ-bAxQ)
# Obligatorisk Oppgave 2 i DATS2300 - Algoritmer og Datastrukturer

Denne oppgaven er en innlevering i DATS2300 - Algoritmer og datastrukturer. Den er innlevert av følgende studenter:
* s123456@oslomet.no
* s654321@oslomet.no
* ...

## Arbeidsfordeling
I oppgaven har vi hatt følgende arbeidsfordeling:
* s123456 har gjort oppgave 1, 3, og 5.
* s654321 har gjort oppgave 2, 4, og 6.
* Vi har samarbeidet om oppgave 7-10.

## Oppgavebeskrivelser

# Oppgave 1
I oppgave 1 gjorde vi ...

# Oppgave 2
I oppgave 2 gjorde vi ...
